<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // for ($i=0; $i <50 ; $i++) { 
        //     DB::table('events')->insert([
        //         'uraian'=>fake()->title(),
        //         'tujuan'=>fake()->sentence(),
        //         'tanggal'=>fake()->date(),
        //         'waktu'=>fake()->time()
        //     ]);
        // }
    }
}
