export default function Join () {
    return (
        <div>
            <form action="/dashboard" method="post">
                

            </form>
        </div>
    )
};